<?php

$wfPHPDeprecatingVersion = '7.0.0'; //When greater than PHP_MINIMUM, will issue a discontinuing warning the first time we check it and find a version less than this (also applies to the other similar constant pairs)
$wfPHPMinimumVersion = '5.5.0'; //The currently supported minimum

$wfOpenSSLDeprecatingVersion = '1.0.1';
$wfOpenSSLMinimumVersion = '1.0.1';

$wfWordPressDeprecatingVersion = '4.7.0';
$wfWordPressMinimumVersion = '3.9.0';
